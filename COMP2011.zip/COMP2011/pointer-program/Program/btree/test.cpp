#include<iostream>

struct btree_node
{
	btree_node* left;
	btree_node* right;
	int data;
};
void mysearch(btree_node* & current, btree_node* & previous, btree_node* & parent, int data)
{
	if (current == nullptr)
		return;
	if (current->data == data)
	{
		return;
	}
	
	btree_node* my_par = parent;
	btree_node* my_pre = previous;

	if (current->left != nullptr)
	{
		previous = nullptr;
		//my_par = current;
		parent = current;
		current = current->left;
		mysearch(current, previous, parent, data);
		if (current->data == data)
		{
			return;
		}
	}
	if (current->right != nullptr)
	{
		previous = current;
		current = current->right;
		parent = my_par;
		mysearch(current, previous, parent, data);
		if (current == nullptr)
			return;
		if(current->data == data)
			return;
	}
	previous = my_pre;
	current = my_par;
}
void searchPatientByID(int ID, btree_node*& current, btree_node*& previous, btree_node*& parent)
{
    if(current==nullptr) //when already reach the leaf
    {
		return;
	}    
    if(current->data==ID) //the root itself is target
    {
        return;
    }    
    
   /*  std::cout << "I find     "<<current->ID<<std::endl;
	std::cout << "parent     "<<((parent == nullptr)? 0 : parent->ID)<<std::endl;
	std::cout << "previous   "<<((previous == nullptr)? 0 : previous->ID)<<std::endl; */
    
    btree_node* my_par=parent;
    btree_node* my_pre=previous;
    
    if(current->left!=nullptr)
    {
        previous=nullptr;
        parent=current;
        current=current->left;
        searchPatientByID(ID,current,previous,parent);
        if(current==nullptr)
        {
			parent=nullptr;
			previous=nullptr;
			return;
		}    
        if(current->data==ID)
        {
            return;
        }    
    }
    if(current->right!=nullptr)
    {
        previous=current;
        current=current->right;
        parent=my_par;
        searchPatientByID(ID,current,previous,parent);
        if(current==nullptr)
        {
			parent=nullptr;
			previous=nullptr;
			return;
		}    
        if(current->data==ID)
            return;
    }    
    
    
    previous=my_pre;
    current=my_par;
};
void remove_negative(btree_node*& root)
{
	btree_node* p=root;
	btree_node* assistant;
	if(root==nullptr)
        return;
	if(root->data<0)
    {
        return;
    }

	if(root->left!=nullptr)
    {
        p=root;
        root=root->left;
        remove_negative(root);
        if(root==nullptr) return;
		if(root->data<0)
        {
            if(root->right!=nullptr && root->left==nullptr)
            {
                p->left=root->right;
                delete root;
                root=nullptr;
                return;
            }
            if(root->right==nullptr && root->left!=nullptr)
            {
                p->left=root->left;
                delete root;
                root=nullptr;
                return;
            }
            if(root->right!=nullptr && root->left!=nullptr)
            {
                for(assistant=root->left;assistant!=nullptr;assistant=assistant->right);
                assistant=root->right;
                p->left=root->left;
                delete root;
                root=nullptr;
                return;
            }
			else
            {
                delete root;
                root=nullptr;
                return;
            }
        }    
    }
	if(root->right!=nullptr)
    {
        p=root;
        root=root->right;
        remove_negative(root);
        if(root==nullptr) return;
		if(root->data<0 )// reach the end of "next" l-list
        {
            if(root->right!=nullptr && root->left==nullptr)
            {
                p->right=root->right;
                delete root;
                root=nullptr;
                return;
            }
            else if(root->right==nullptr && root->left!=nullptr)
            {
                p->right=root->left;
                delete root;
                root=nullptr;
                return;
            }
            else if(root->right!=nullptr && root->left!=nullptr)
            {
                for(assistant=root->left;assistant!=nullptr;assistant=assistant->right);
                assistant=root->right;
                p->right=root->left;
                delete root;
                root=nullptr;
                return;
            }
            else
            {
                delete root;
                root=nullptr;
                return;
            }
        }
    }
	root=p;

}
void print_btree(const btree_node* root, int depth=0) 
{
    if (root == nullptr)   // Base case
        return;
    for (int j = 0; j < depth; j++)   // Print the node data
        std::cout << '\t';
    std::cout << root->data <<"\n";
    print_btree(root->left, depth+1);// Recursion: right subtree
    print_btree(root->right, depth); // Recursion: left subtree
}
int stat(btree_node* root, int day)
{
	
	if(root==nullptr)
    {
        return 0;
    }    
    
    if(root->data==day)
    {    
        return stat(root->left, day)+stat(root->right, day)+1;
    }
    else
    {
        return stat(root->left, day)+stat(root->right, day);
    }
}
int main()
{
	btree_node node[15];
	for (int i = 1; i < 15; i++)
	{
	node[i].data = i;
	node[i].left = nullptr;
	node[i].right = nullptr;

	}
	node[1].left = &node[3];
	node[3].left = &node[7];
	node[7].left = &node[9];
	node[4].left = &node[6];
	node[6].left = &node[8];
	node[10].left = &node[11];

	node[1].right = &node[2];
	node[2].right = &node[4];
	node[3].right = &node[5];
	node[7].right = &node[14];
	node[9].right = &node[12];
	node[12].right = &node[13];
	node[8].right = &node[10];

	print_btree(&node[1]);
	
	
	//node[1].data=-1;
	int id=24;
	std::cout<<"when day="<<id<<" there are "<<stat(&node[1],id)<<" people\n";
	print_btree(&node[1]);
	btree_node* cur_root=&node[1];
	//remove_negative(cur_root);
	

	

	btree_node* current= &node[1];
	btree_node* previous= nullptr;
	btree_node* parent = nullptr;
	int data = 88;
	
 	//mysearch(current, previous, parent, data);
	searchPatientByID(data, current,  previous,  parent);

	if (current == nullptr && parent == nullptr && previous == nullptr)
	{
		std::cout << "I am sorry,not found\n";
		return 0;
	}

	else
	{
		std::cout << "I find     "<<current->data<<std::endl;
		std::cout << "parent     "<<((parent == nullptr)? 0 : parent->data)<<std::endl;
		std::cout << "previous   "<<((previous == nullptr)? 0 : previous->data)<<std::endl;
		return 0;
	} 
	
}