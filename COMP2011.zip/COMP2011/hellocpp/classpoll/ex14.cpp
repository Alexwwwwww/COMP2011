#include <iostream> 
using namespace std;

struct foo1{
    int x;      // size a
    int y;      // size a
};

struct foo2{ 
    int x;      // size a
    foo1* p1;   // size b 
    foo1* p2;   // size b
};

int f1(foo1* p){
    return p->x + p->y;
}

int f2(foo2* p){
    // return (10+15)+(20+25)
    int r1 = f1(p->p1);
    int r2 = f1(p->p2);
    
    return (r1+r2);
}

int main(){
    foo2* h = new foo2;  // how much memory i get?  a + 2b
    h->p1 = new foo1;     // 2a
    h->p2 = new foo1;      // 2a

    h->p1->x=10;
    h->p1->y=15;
    h->p2->x=20;
    h->p2->y=25;


    h->x = f2(h);
    cout<<h->x<<endl;
    
    delete h->p1; 
    delete h->p2; 
    delete h;
    
    h=nullptr;
    return 0;
}