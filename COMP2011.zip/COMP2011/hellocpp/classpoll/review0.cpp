#include <iostream>
using namespace std;

struct intnode{int x;intnode* next;};

intnode* initList(intnode*& head, int f, int t, int s){ // from f to t with step s
    intnode* tmp=nullptr;
    if((f<t && s>0) || (f > t && s<0)){ 
        int value = f;      
        tmp = new intnode; 
        tmp->x = value;     
        value+=s;             
        head = tmp;         
        int a;
        if(f<t){a=1;}else{a=-1;}  //can actually judge if it exceed the target value: larger if step <0, vice versa
        while(a*value<=a*t){     //eventually compact 2 situations in a single while loop
            tmp->next = new intnode; 
            tmp->next->x = value;
            tmp->next->next=nullptr;
            tmp = tmp->next; 
            value+=s;         // increase the value by step by still don't "exceed" in a way
        }
        return head;
    }else{
        cout<<"invalid input"<<endl;
        return nullptr;
    } 
}

void printer(intnode*& head){
    for(intnode* ptr = head; ptr!=nullptr;ptr=ptr->next){
        cout<< ptr -> x<<"\t";
    }
    cout<<endl;
} 

int main(){
    intnode* head1 = initList(head1, 10,1,-2);  // linked list is a flexible way to store all kinds of data, performing all kinds of functions, and better sorted
    printer(head1);

    
    intnode* head2 = initList(head2, 1,15,3);
    printer(head2);

    intnode* head3 = initList(head3, 1,15,-3);
    printer(head3);
    
    return 0;
}