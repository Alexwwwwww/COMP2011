#include <iostream> 
using namespace std;

int fun(const int data[],int i,int j){
    if(i<j){
        if(data[i]%2){
            return data[i]+fun(data,i+1,j);
        }else{
            return fun(data,i+1,j);
        }
    }else{
        return 0;
    }
}

int main()
{
    int a[] = {1,2,3,4,5,6};
    cout<<fun(a,0,6)<<endl;
    return 0;
}