#include <iostream>
using namespace std;

int oneDice();


int main()
{
int total = 0, value;
for (int i = 1; i <= 10; i++)
{
value = oneDice();
if ( (i % 2) == 1 )
total += value;
else
total -= value;
}

cout << "total = " << total << endl;

return 0;

}
int oneDice()
{
    return 0;
}