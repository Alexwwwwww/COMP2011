#include <iostream> 
using namespace std;

int fun(const int data[],int i,int j,int k){
    if(i<j){ // 1<7
        if(data[i]==k){
            return i;
        }else{
            return fun(data,i+1,j,k); // a = {2,3,4,5,6,7};
        }
    }else{
        return -1;
    }
}

int main()
{
    int a[] = {0,1,2,3,4,5,6,7};
    int x = fun(a,0,8,4); cout<<x<<endl; // a = {0,1,2,3,4,5,6,7};
    int y = fun(a,0,8,8); cout<<y<<endl; // a = {0,1,2,3,4,5,6,7};
    cout<<x+y<<endl;

    return 0;
}