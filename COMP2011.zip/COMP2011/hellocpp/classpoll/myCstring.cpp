/* #include <iostream>
#include <cstring>
using namespace std;
char* duplicate(const char p[])
{
    char q[20];
    strcpy(q,p);
    return q;
}
int main()
{
    char* a[10]={"AAA","BBB","CCC"};
    char** b;
    b=a;
    cout<<b[0]<<endl;
    return 0;
} */
#include <iostream>
#include <cstring>
using namespace std;

int minionDice()
{
int value1 = 1 + rand()%6;
int value2 = 1 + rand()%6;
int value3 = 1 + rand()%6;
cout << "roll: " << value1 << " " << value2 << " " << value3 << endl;
if (value1 == 6)
value1 += minionDice();
if (value2 == 6)
value2 += minionDice();
if (value3 == 6)
value3 += minionDice();
return (value1 + value2 + value3);
}



int main() {

    // char a[2][3]={{0,1,2},{3,4,5}};
    /* 
    'a' 'b' 'c'
    'e' 'f' 'g'
    */

/*    //cout<<a<<endl;
    cout<<a+1<<endl;
    cout<<a<<endl;
    cout<<&a[0][0]<<endl;
    return 0; */
    char s1[]="Minato";
    char s2[]="Takato";
    cout<<strcmp(s1,s1)<<endl;
    char* p;
    p=s1;
    cout<<p<<endl;
    int a=34,b=56;
    int* aptr=&a;
    int* bptr=&b;
    //aptr=*bptr;
    //cout<<aptr<<"   "<<bptr<<endl;
    minionDice();
}