#include <iostream> 
using namespace std;

void fun(const char data[],int i,int j){
    if(i<j){
        cout<<i<<","<<data[i]<<endl;
        fun(data,i+1,j); 
        cout<<i<<","<<data[i]<<endl; //will be first executed after fun(data,5,5);  
    }
    //do not enter if for i=5;
}

int main()
{
    char a[] = "hello";
    fun(a,0,5);
    cout<<endl;
    return 0;
}