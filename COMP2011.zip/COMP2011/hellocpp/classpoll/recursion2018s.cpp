#include <iostream>
using namespace std;

void recursiveSort(int arr[], int size, int index)
{
    if (index==size-1)
    return;
    for (int i=index; i<size; i++)
    {
        if (arr[index]>arr[i])
        {
            int tmp=arr[index];
            arr[index]=arr[i];
            arr[i]=tmp;
        }
    }
    recursiveSort(arr,  size, index+1);
}


int main(){
    
    int a[] = {10, 6, 4, 5, 3};
    for (int i=0; i<sizeof(a)/sizeof(int); i++){
        cout << a[i] << "\t";
    }
    cout << endl;
    recursiveSort(a, sizeof(a)/sizeof(int), 0);
    for (int i=0; i<sizeof(a)/sizeof(int); i++){
        cout << a[i] << "\t";
    }
    cout << endl;
 
    return 0;
}