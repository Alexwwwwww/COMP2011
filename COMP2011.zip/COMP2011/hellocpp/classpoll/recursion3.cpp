#include <iostream> 
using namespace std;

int fun(const int data[],int i,int j,int k){
    if(i<j){
        if(data[i]>k){ // check if data[i] > than k , k stores the max value
            return fun(data,i+1,j,data[i]);
        }else{
            return fun(data,i+1,j,k);
        }
    }else{
        return k;
    }
}

int main()
{
    int a[] = {1,25,20,3,4,5,6};
    cout<<fun(a,0,7,-1)<<endl;
    return 0;
}
