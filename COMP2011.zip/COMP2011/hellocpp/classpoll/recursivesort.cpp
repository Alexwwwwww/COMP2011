#include <iostream>
using namespace std;

void recursiveSort(int arr[], int size, int index);

int main()
{
int a[] = {10, 6, 4, 5, 3};
recursiveSort(a, sizeof(a)/sizeof(int), 0);

for (int i=0; i<sizeof(a)/sizeof(int); i++)
cout << a[i] << " ";
cout << endl;

return 0;

}
void recursiveSort(int arr[], int size, int index)
{
    if(index==size-1)
    return;
    int i,tmp;
    for (i=index;i<size;i++)
    {
       if(arr[index]>arr[i])
        {
          tmp=arr[i];
          arr[i]=arr[index];
          arr[index]=tmp;
        }
    }
    recursiveSort(arr, size, index+1);
}