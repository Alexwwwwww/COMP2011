#include <iostream>
#include <cmath>
using namespace std;
struct btnode
{
    int data;
    btnode* left;
    btnode* right;
};
btnode* create_btree_node(int data)
{
    btnode* node = new btnode;
    node->data = data; 
    node->left = node->right = nullptr;
    return node;
}

int height(const btnode* root)
{
	if (root==nullptr)
	return 0;
	int l_height, r_height;
    l_height= height (root->left)+1;
	r_height=height (root->right)+1;
	return (l_height >r_height)?l_height:r_height;
}
int size(const btnode* root)
{
	if (root==nullptr)
	return 0;
	int l_size, r_size;
    l_size=size(root->left);
    r_size=size(root->right);
	return 1+l_size+r_size;
}
void one_level_2_array(const btnode* root, int array[], int& index, int level)
{
	if(root==nullptr) return;
    if (level==1)
	{
		array[index]=root->data;
		index++;
		return;
	}
	one_level_2_array(root->left, array,  index, level-1);
	one_level_2_array(root->right, array,  index, level-1);
}
int btree_2_array(const btnode* root, int array[])
{
	int index=0;
	for(int i=1;i<=height(root);i++)
	one_level_2_array(root, array,  index, i);
    return index;
}
int main()
{ /* Create the binary tree as shown in the above picture */
btnode* root = create_btree_node(-9);
root->left = create_btree_node(2);
root->right = create_btree_node(0);
root->left->left = create_btree_node(4);
root->left->right = create_btree_node(11);
root->right->left = create_btree_node(-7);
root->left->left->left = create_btree_node(12);
root->left->right->left = create_btree_node(9);
root->left->right->right = create_btree_node(-8);

// Create an empty array with enough memory to store the tree data
int tree_height = height(root);
int* array = new int [static_cast<int>(pow(2, tree_height)) - 1];

// Copy all binary tree data to an array level by level
int num_nodes = btree_2_array(root, array);

// Print the tree/array data or information
cout << "height of the binary tree = " << tree_height << endl; // height = 4
cout << "size of the binary tree = " << num_nodes << endl; // size = 9
cout << "content of the array: ";
for (int i = 0; i < num_nodes; ++i)
cout << array[i] << " "; // -9 2 0 4 11 -7 12 9 -8
cout << endl;
/* Codes to release all dynamically allocated memory */
}