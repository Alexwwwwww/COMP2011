#include <iostream>
using namespace std;

struct item
{
    char* name;
    int id;
};
void func(item* a) //if it is a pointer then operating on the memory space it is pointing to directly
{
    char text[20]="cabinet";
    //cout<<a->name<<endl;
    item temp={&text[0],10};
    //cout<< &temp.id<<"\t"<<&a.id<<endl;
    //cout<<temp.name<<endl;
    *a=temp;
    //cout<< &temp.id<<"\t"<<&a.id<<endl;
}
int main()
{
    item* a=new item;
    func(a);
    cout<< a->name<<"\t"<<a->id<<endl;
    return 0;
}