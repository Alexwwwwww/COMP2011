#include <iostream> 
using namespace std;

struct i_node{ 
    int x; 
    struct i_node* next;
};

void printNode(struct i_node* n, string s="Node"){
    cout<<s<<" "<<n<<" stores: "<<n->x<<" and points to: "<<n->next<<endl;
}

struct i_node* addNode(struct i_node* head, int a){
    struct i_node *p, *q, *r;

    p = new i_node; // allocating memory 
    p->x = a; 
    p->next = nullptr;

    if(head==nullptr){
        head=p; 
        p->next=head;
    }else{
        if(head->next == head){ // the list contains only one element
            if(head->x<=a){
                head->next = p;
                p->next = head;
            }else{
                p->next = head;
                head->next=p;
                head = p;
            }
        }else{  // The list contains multiple elements
            if(head->x>a){
                for(q=head->next,r=head; q!=head; r=q, q=q->next);
                r->next = p;
                p->next = head; 
                head = p;
            }else{
                for(q=head->next,r=head; q!=head && q->x<=a; r=q, q=q->next);
                p->next = q;
                r->next = p;
            }
        }
    }
    return head;
}

void printer_oneline(i_node* ptr){
    i_node* p;
    if(ptr!=nullptr){
        cout<<ptr->x<<"\t";
    }
    for (p = ptr->next; p!=ptr; p = p->next){
        cout << p->x << "\t";
    }
}

void printer(i_node* ptr){
    i_node* p;
    for (p = ptr; p!=nullptr; p = p->next){
        cout << "Node adr: \t"<<p<<endl;
        cout << "Data\t\t["<< p->x << "]"<<endl;
        cout << "Next node adr:\t"<< p->next<<endl<<endl;
    }
}

int main(){
    struct i_node* h = nullptr; // initialize the head to null -> empty list
    h = addNode(h,2); printer_oneline(h);cout<<endl;    
    h = addNode(h,20); printer_oneline(h);cout<<endl;
    h = addNode(h,1); printer_oneline(h);cout<<endl;    
    h = addNode(h,10); printer_oneline(h);cout<<endl;    
    h = addNode(h,4); printer_oneline(h);cout<<endl;
    h = addNode(h,0); 
    printer_oneline(h);cout<<endl;
    return 0;
}

