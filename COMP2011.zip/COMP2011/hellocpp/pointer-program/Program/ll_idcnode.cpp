#include <iostream> 
using namespace std;

struct ll_idcnode{
    int x;
    double d;
    char c;
    ll_idcnode* next;
};

int main(){  

    ll_idcnode* head = nullptr;

    ll_idcnode* p = new ll_idcnode;
    
    p->x = 0;
    p->d = 1.5;
    p->c = 'a';
    p->next = head; // p->next = null
    head = p;       // head points to 0
    
    cout<<"1) p:\t\t"<<p<<endl;
    cout<<"1) head:\t"<<head<<endl;
    cout<<endl;

    p = new ll_idcnode;
    p->x = 1;
    p->d = 2.75;
    p->c = 'b';
    p->next = head;  // p->next = 0
    head = p;       // head points to 1

    cout<<"2) p:\t\t"<<p<<endl;
    cout<<"2) p->next:\t"<<p->next<<endl;
    cout<<"2) head:\t"<<head<<endl;
    cout<<endl;
    
    p = new ll_idcnode;
    p->x = 2;
    p->d = 4.725;
    p->c = 'c';
    p->next = head; // p->next points to 1
    head = p;       // head points to 2
    
    cout<<"3) p:\t\t"<<p<<endl;
    cout<<"3) p->next:\t"<<p->next<<endl;
    cout<<"3) head:\t"<<head<<endl;
    cout<<endl;

    int length = 0;
    int lookfor = 2;
    for (p = head; p!=nullptr; p = p->next){
        length++;
        cout << p->x << "\t"<<p->d<<"\t"<<p->c<<endl;
        if(p->x==lookfor){
            cout<<"Found!!!"<<endl;
        }
    }
    
    cout<<length<<endl;
    return 0;
}
