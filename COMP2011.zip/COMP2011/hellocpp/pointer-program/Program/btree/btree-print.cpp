#include "btree.h"      /* File: btree-print.cpp */

void print_btree(const btree_node* root, int depth) 
{
    if (root == nullptr)   // Base case
        return;
    if(root->right!=nullptr)//!!!!!!
    print_btree(root->right, depth+1);// Recursion: right subtree

    for (int j = 0; j < depth; j++)   // Print the node data
        cout << '\t';
    cout << root->data << endl;
    if(root->left!=nullptr)//!!!!!!
    print_btree(root->left, depth+1); // Recursion: left subtree
}
int count_tree(btree_node* cur_root)
{
    if(cur_root==nullptr)
        return 0;
    int lheight=count_tree(cur_root->right)+1;
    int rheight=count_tree(cur_root->left)+1;
    return (lheight>rheight)?lheight:rheight;
}
/* int count_node(btree_node *cur_root)
{
    if (cur_root == nullptr)
        return 0;
    return count_node(cur_root->right) + count_node(cur_root->left) + 2;
}
 */