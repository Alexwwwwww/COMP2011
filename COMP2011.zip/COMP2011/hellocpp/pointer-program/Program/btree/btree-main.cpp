
#include "btree.h"      /* File: btree-main.cpp */
int main()
{   
    btree_node* root = create_btree_node(10); // Create root node

    root->left = create_btree_node(8);   // Create the left sub-tree
    root->left->left = create_btree_node(4);
    root->left->left->left = create_btree_node(5);
    root->left->left->right = create_btree_node(9);
    root->left->left->right->right = create_btree_node(10);
    root->left->left->right->right->left = create_btree_node(11);
    root->left->left->right->right->right->left = create_btree_node(12);

    root->right = create_btree_node(15); // Create the right sub-tree
    root->right->left = create_btree_node(12);
    root->right->right = create_btree_node(17);
    root->right->right->right = create_btree_node(18);
    root->right->right->right = create_btree_node(19);

    print_btree(root);  // Print the resulting tree
    cout<<endl<<"the height is "<<count_tree(root)<<endl;
    delete_btree(root->left);            // Delete the left sub-tree
    cout << "\n\n\n"; print_btree(root); // Print the resulting tree
    cout<<endl<<"the height is "<<count_tree(root)<<endl;

    return 0;
}
