#include <iostream> 
using namespace std;
int find_power(int a, int k)
{
    if(k==0)
        return a;
    else
    {
        return find_power(a,k-1)*find_power(a,k-1);
    }
}
int main()
{
    int a=5,b=3;
    find_power(a,b);
    return 0;
}