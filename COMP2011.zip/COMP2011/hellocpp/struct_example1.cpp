#include <iostream>
using namespace std;

struct comp2011Grade{ // 0 - 100
    int labs;
    int pa1; int pa2; int pa3;
    int quiz;
    int final;
};

void init_comp2011Grade(comp2011Grade& g, int labs, int pa1, int pa2, int pa3, int quiz, int final){
    g.labs = labs;
    g.pa1 = pa1; g.pa2 = pa2; g.pa3 = pa3;
    g.quiz = quiz;
    g.final = final;
}

void print_comp2011Grade(const comp2011Grade g){
    cout<<"/---------------\\"<<endl
        <<"Grades in detail:"<<endl
        <<"Labs:\t"<<g.labs <<endl
        <<"pa1:\t"<<g.pa1<<endl
        <<"pa2:\t"<<g.pa2<<endl
        <<"pa3:\t"<<g.pa3<<endl
        <<"quiz:\t"<<g.quiz<<endl
        <<"final:\t"<<g.final<<endl
        <<"\\---------------/"<<endl<<endl;
}

bool passORfail(const comp2011Grade g, int X, double Y){
    if(g.final>=X && (0.08*g.final+0.45*g.quiz>=Y)){return true;}
    return false;
}

int final_score(const comp2011Grade g){
    double score=0;
    score += 0.1*g.labs;
    score += 0.1*g.pa1 + 0.12*g.pa2 + 0.15*g.pa3;
    score += 0.08*g.quiz;
    score += 0.45*g.final;
    return score;
}

void notification(const comp2011Grade g, const int X, const double Y){
    bool pof = passORfail(g,X,Y);
    if(pof){
        cout<<"Pass! with overall score: "<< final_score(g)<<endl;
    }else{
        if(g.final < X && 0.08*g.final+0.45*g.quiz < Y){
            cout<<"Fail because both your final and quiz scores are low."<<endl;
        }else if (0.08*g.final+0.45*g.quiz < Y)
        {
            cout<<"Fail because your combined score on proctored exams is low."<<endl;
        }else{
            cout<<"Fail because your score in the final exam is low."<<endl;
        }
    }
    print_comp2011Grade(g);
}

int main()       
{
    comp2011Grade g1 = {90, 80, 90, 100, 75, 60};
    comp2011Grade g2, g3;

    g2.labs=80; g2.pa1=100; g2.pa2=95; g2.pa3=80; g2.quiz=100; g2.final=25;

    init_comp2011Grade(g3,100,100,100,100,10,10);

    //print_comp2011Grade(g1);
    //print_comp2011Grade(g2);
    //print_comp2011Grade(g3);

    notification(g1,50,15.5);
    notification(g2,50,15.5);
    notification(g3,50,15.5);
    return 0;
}