#include <iostream> /* File: odd-even.cpp */
using namespace std;

int main()
{
    const int WORD_LEN=15;
    const int WORD_NUM=10;
    char words[WORD_NUM][WORD_LEN+1]={
        "Kobashi",
        "Minato",
        "Takato",
        "Yutaka"
    }
    std::cout<<words[0][0]<<endl;
    return 0;
}