/* Include guard */
#ifndef LAB7_H
#define LAB7_H

#include <iostream>
#include <stdlib.h>
#include <string>

/* Constant definitions */
const int MAX_BOARD_SIZE = 10;

/* Struct definitions */
struct Player{
    char letter = '\0';
    int loc[2] = {0,0};
    int weight = 0;
};

/* External function declarations */
// TODO 1
void initialize_player(Player ps[] , int );

bool check_inside(const Player& );

void show_player(const Player& );

void initialize_board(char[][MAX_BOARD_SIZE], const Player ps[]);

void show_board(const char);

bool check_number(char );

bool check_wasd(char );

void update(char , Player& , char );

int check_win(char , const Player& );

bool check_flag(int , const Player& );

void play_game(Player [], char [][MAX_BOARD_SIZE]);

#endif
