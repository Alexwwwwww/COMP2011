#include <iostream>
using namespace std;
  

int main()
{    
   
   
    int a[]={67,34,79,54,89,47,98};


    //find(a,max,0);
    int key_id,key,i,j;
    bool swap;
    for (key_id=1 ; key_id<=6 ; key_id++)
    {   
        swap=false;
        key=a[key_id];
        for(j=0;j<=key_id-1;j++)
        {
            if(key<a[j])
            {
                swap=!swap;
                cout<<"swap "<<a[j] <<" with "<<key<<endl;
                break;
            }

        }
        if(swap)
        {
            for(i=key_id;i>=j+1;i--) //start from the jth index to the key_ind , shift 1 unit to right
            {
                a[i]=a[i-1];
            }
                a[i]=key;
        }
        for (int id=0;id<=6;id++)
            cout<<a[id]<<"  ";
        cout<<endl;
    }
    cout<<endl;
    for (int id=0;id<=6;id++)
        cout<<a[id]<<"  ";
     
} 
