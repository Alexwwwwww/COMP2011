#include <iostream>

using namespace std;

int main(){

    // Initializing variables to store the positions of all pieces.
    int A_x = 0, A_y = 0;
    int B_x = 1, B_y = 0;
    int C_x = 2, C_y = 0;

    int D_x = 0, D_y = 2;
    int E_x = 1, E_y = 2;
    int F_x = 2, F_y = 2;

    // Initializing other variables
    unsigned int round = 1;  // The round number of the game.
    char piece = ' '; // Variable to store which piece the player select.
    unsigned int direction = 0; // Variable to store which direction the player select.
    int posx_select,posy_select;//get the selected position
    cout << "Game Start!" << endl;

    // Enter a loop until one player wins.
    while(true){
        cout << "Round " << round << endl;

        // This part is for printing the board.
        for(int i=0; i<3; i++) {
            cout << endl;
            for(int j=0; j<3; j++) {
                char pos = (A_x==i && A_y==j)?'A': (B_x==i && B_y==j)?'B':
                (C_x==i && C_y==j)?'C': (D_x==i && D_y==j)?'D':
                (E_x==i && E_y==j)?'E': (F_x==i && F_y==j)?'F':'*';
                cout << pos;
                if (j<2) cout<<"   ";
            }
            cout << endl;
        }

        // Player1 starts first.
        cout << "Player 1:" << endl;

        // TODO 1: Ask the player to input the piece to select and store the input.
        cout<<"Please select the piece to move (A, B or C):";
        cin>>piece;

        /* TODO 2: Check whether the input is valid. If not, ask the player to input again.
         If the input is valid, get the coordinates of the selected piece. */
        if (piece<65 || piece>67)
        {
            printf("%c is not a valid piece\n",piece);
            cout<<"Please select the piece to move (A, B or C):";
            cin>>piece;
            cout<<endl;
        }    
        
        if(piece=='A')
            posx_select=A_x,posy_select=A_y;
        else if(piece=='B')
            posx_select=B_x,posy_select=B_y;
        else if(piece=='C')
            posx_select=C_x,posy_select=C_y;  
        // TODO 3: Ask the player to input the direction to move and store the input.
        cout<<"Please select the direction to move (0-7):";
        cin>>direction;
        // TODO 4: Check whether the input is valid. If not, ask the player to input again.
        if (direction>7)
        {
            cout<<"Please select the direction to move (0-7):";
            cin>>direction;
            cout<<endl;
        }    
        
        bool canMove = false; //Boolean variable that indicates if the piece can move to the direction.
        while(!canMove)
        {
            canMove = true;
            /* TODO 5: Check if the selected piece can move to the selected direction:
                1. There is no direct line between the original position and the target position of selected piece on the board.
                2. After moving, the piece is out of the board.
                3. There is another piece on the target position.
            If any of above conditions is true, set canMove to false and ask the player to input a direction again*/
            if (direction==0 || direction==6 || direction==7)
                posy_select--;
            if(direction==2 || direction==3 || direction==4)
                posy_select++;
            if(direction==0 || direction==1 || direction==2)
                posx_select--;
            if(direction==4 || direction==5 || direction==6)
                posx_select++; //simulate the move
            //cout<<"x="<<posx_select<<endl;
            //cout<<"y="<<posy_select<<endl;
            if(posx_select>2 || posx_select<0||posy_select>2 || posy_select<0)
            {
                //cerr<<"type1\n";
                cout<<"can't move to direction "<<direction<<endl;
                if(piece=='A')
                    posx_select=A_x,posy_select=A_y;
                else if(piece=='B')
                    posx_select=B_x,posy_select=B_y;
                else if(piece=='C')
                    posx_select=C_x,posy_select=C_y;  
                cout<<"Please select the direction to move (0-7):";
                cin>>direction;
                canMove = false;
                continue;
            }
            if((posx_select==A_x&&posy_select==A_y)||(posx_select==B_x&&posy_select==B_y)||(posx_select==C_x&&posy_select==C_y)
            ||(posx_select==D_x&&posy_select==D_y)||(posx_select==E_x&&posy_select==E_y)||(posx_select==F_x&&posy_select==F_y))
            {
                //cerr<<"type2\n";
                cout<<"can't move to direction "<<direction<<endl;
                if(piece=='A')
                    posx_select=A_x,posy_select=A_y;
                else if(piece=='B')
                    posx_select=B_x,posy_select=B_y;
                else if(piece=='C')
                    posx_select=C_x,posy_select=C_y;  
                cout<<"Please select the direction to move (0-7):";
                cin>>direction;
                canMove = false;
                continue;
            }


        }

        // TODO 6: Update the position of pieces after moving.
        if(piece==65)
            A_x=posx_select,A_y=posy_select;
        else if(piece==66)
            B_x=posx_select,B_y=posy_select;
        else if(piece==67)
            C_x=posx_select,C_y=posy_select;

        // TODO 7: Check if Player1 wins. If so, exit the loop.
        //cout<<((A_x-B_x)*(B_y-C_y)==(B_x-C_x)*(A_y-B_y))<<endl;
        //cout<<(A_y-B_y)<<" AND "<<(A_x+B_x)<<endl;
        //cout<<A_x<<"-"<<B_x;
        if ((A_x-B_x)*(B_y-C_y)==(B_x-C_x)*(A_y-B_y)&&((A_y-B_y)/(A_x-B_x)==-1 ||(A_y-B_y)/(A_x-B_x)==1))
        {
            cout<<"player1 wins!";
            break;
            
        }

        // Printing the board again.
        for(int i=0; i<3; i++) {
            cout << endl;
            for(int j=0; j<3; j++) {
                char pos = (A_x==i && A_y==j)?'A': (B_x==i && B_y==j)?'B':
                (C_x==i && C_y==j)?'C': (D_x==i && D_y==j)?'D':
                (E_x==i && E_y==j)?'E': (F_x==i && F_y==j)?'F':'*';
                cout << pos;
                if (j<2) cout<<"   ";
            }
            cout << endl;
        }

        cout << "Player 2:" << endl;
        // TODO 8: Repeat the game steps for Player2.
         // TODO 1: Ask the player to input the piece to select and store the input.
        cout<<"Please select the piece to move (D, E or F):";
        cin>>piece;

        /* TODO 2: Check whether the input is valid. If not, ask the player to input again.
         If the input is valid, get the coordinates of the selected piece. */
        if (piece<68 || piece>70)
        {
            printf("%c is not a valid piece\n",piece);
            cout<<"Please select the piece to move (D, E or F):";
            cin>>piece;
            cout<<endl;
        }    
        
        if(piece=='D')
            posx_select=D_x,posy_select=D_y;
        else if(piece=='E')
            posx_select=E_x,posy_select=E_y;
        else if(piece=='F')
            posx_select=F_x,posy_select=F_y;  
        // TODO 3: Ask the player to input the direction to move and store the input.
        cout<<"Please select the direction to move (0-7):";
        cin>>direction;
        // TODO 4: Check whether the input is valid. If not, ask the player to input again.
        if (direction>7)
        {
            cout<<"Please select the direction to move (0-7):";
            cin>>direction;
            cout<<endl;
        }    
        
        canMove = false; //Boolean variable that indicates if the piece can move to the direction.
        while(!canMove){
            canMove = true;
            /* TODO 5: Check if the selected piece can move to the selected direction:
                1. There is no direct line between the original position and the target position of selected piece on the board.
                2. After moving, the piece is out of the board.
                3. There is another piece on the target position.
            If any of above conditions is true, set canMove to false and ask the player to input a direction again*/
            if (direction==0 || direction==6 || direction==7)
                posy_select--;
            if(direction==2 || direction==3 || direction==4)
                posy_select++;
            if(direction==0 || direction==1 || direction==2)
                posx_select--;
            if(direction==4 || direction==5 || direction==6)
                posx_select++;
            if(posx_select>2 || posx_select<0||posy_select>2 || posy_select<0)
            {
                if(piece=='D')
                    posx_select=D_x,posy_select=D_y;
                else if(piece=='E')
                    posx_select=E_x,posy_select=E_y;
                else if(piece=='F')
                    posx_select=F_x,posy_select=F_y;  
                cout<<"can't move to direction "<<direction<<endl;
                cout<<"Please select the direction to move (0-7):";
                cin>>direction;
                canMove = false;
                continue;
            }
            if((posx_select==A_x&&posy_select==A_y)||(posx_select==B_x&&posy_select==B_y)||(posx_select==C_x&&posy_select==C_y)
            ||(posx_select==D_x&&posy_select==D_y)||(posx_select==E_x&&posy_select==E_y)||(posx_select==F_x&&posy_select==F_y))
            {
                cout<<"can't move to direction "<<direction<<endl;
                if(piece=='D')
                    posx_select=D_x,posy_select=D_y;
                else if(piece=='E')
                    posx_select=E_x,posy_select=E_y;
                else if(piece=='F')
                    posx_select=F_x,posy_select=F_y;
                cout<<"Please select the direction to move (0-7):";
                cin>>direction;
                canMove = false;
                continue;
            }


        }

        // TODO 6: Update the position of pieces after moving.
        if(piece==68)
            D_x=posx_select,D_y=posy_select;
        else if(piece==69)
            E_x=posx_select,E_y=posy_select;
        else if(piece==70)
            F_x=posx_select,F_y=posy_select;

        // TODO 7: Check if Player1 wins. If so, exit the loop.
        if ((D_x-E_x)*(E_y-F_y)==(E_x-F_x)*(D_y-E_y)&&((D_x-E_x)/(D_y-E_y)==-1 ||(D_x-E_x)/(D_y-E_y)==1))
        {
            break;
            cout<<"player2 wins!\n"; 
        }

        // Printing the board again.
        for(int i=0; i<3; i++) {
            cout << endl;
            for(int j=0; j<3; j++) {
                char pos = (A_x==i && A_y==j)?'A': (B_x==i && B_y==j)?'B':
                (C_x==i && C_y==j)?'C': (D_x==i && D_y==j)?'D':
                (E_x==i && E_y==j)?'E': (F_x==i && F_y==j)?'F':'*';
                cout << pos;
                if (j<2) cout<<"   ";
            }
            cout << endl;
        }

        round += 1;
    }
    return 0;
}