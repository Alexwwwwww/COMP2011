#include <iostream>
using namespace std;
  
int find(int a[],int max, int id)
{
    int length=sizeof(a);
    //cout<<"length="<<length<<endl;
    if (id==length)
    {
        cout<<id<<" max= ";
        return max;
    }
    if(a[id]>max)
    {
        cout<<id<<endl;
        return find(a,a[id],id+1);
    }
    else
    {
        cout<<id<<endl;
        return find(a,max,id+1);
    }
}
int main()
{    
   
   
    int a[]={67,34,79,54,89,47,98};
    cout<<"the length of the array is "<<sizeof(a)<<endl;
    cout<<"the length of the int is "<<sizeof(int)<<endl;
    cout<<"the number of value inside the array is "<<sizeof(a)/sizeof(int)<<endl;
    cout<<boolalpha<<(7==sizeof(a)/sizeof(int))<<endl;
    int max=0, id=0;
    find(a,max,0);
    return 0;

    
} /*
    string s="MEET AT THE PARK";
    bool bool_array[16]={0};
    char n;
    //cout<<s.find("ar");
    
    for(int i=0;i<=15;i++)
    {
        if(s[i]==' ')
            continue;
        n=(5*(s[i]-'A')+8)%26+'A';
        cout<<s[i]-'A'<<" to "<<(5*(s[i]-'A')+8)%26<<" is "<<n<<endl;
        cout<<boolalpha<<bool_array[i];
    }
    */