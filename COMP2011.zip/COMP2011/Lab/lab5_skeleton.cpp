#include <iostream>
#include <fstream>
#include <string>     // std::string, std::to_string  

using namespace std;
#define MAX_NUM_STU 10  //maximum number of students
#define NUM_INIT 5  //number of initial students

//Save initial data into the file.
void init(const int id[], const string name[], const float grade[], const string filename){
    ofstream ofs(filename);
    int i;

    if (ofs){
        ofs << "ID" << "\t" << "Name" << "\t" << "Grade" << endl;
        for (i=0; i<NUM_INIT; i++){
            ofs << id[i] << "\t" << name[i] << "\t"  << grade[i] << endl;
        }
        ofs.close();
        cout << "Initialization success!" << endl;
    }
    else{
        cerr << "Error: Cannot open " << filename << endl;
        exit(1);
    }
}

//Print all entries in the file.
void display(const string filename){
    ifstream ifs(filename);
    string line;

    if (ifs){
        while (true){
            getline(ifs, line);
            if(ifs.eof()) break;
            cout << line << endl;
        }
        ifs.close();
    }
    else{
        cerr << "Error: Cannot open " << filename << endl;
        exit(1);
    }
}

//TODO1: append a new entry to the file.
void append(const int id, const string name, const float grade, const string filename)
{
    int i=0;
    string convert,data_cpy[MAX_NUM_STU];
    ifstream ifs(filename);
    if(ifs)
    {
        while(!ifs.eof())
        {
            getline(ifs,data_cpy[i]);
            //cout<<data_cpy[i]<<endl;   //to be delete
            i++;
        }ifs.close( );
    }
    else
    {
        cerr << "Error: Cannot open " << filename << endl;
        exit(1);
    }
    
    convert=to_string(id)+"\t"+name+"\t"+to_string(grade).substr(0,4);
    data_cpy[id]=convert;
    //for(i=0;data_cpy[i]!="";i++)
    //{
        //cout<<data_cpy[i]<<endl;
    //}
    ofstream ofs(filename);
    for(i=0;data_cpy[i]!="";i++)
    {
        
        ofs<<data_cpy[i]<<endl;
    }
    ofs.close( );
}
//TODO2: look up one entry by the name. 
//If find succesfully, print out his/her information and return true, otherwise, return false.
bool lookup(const string name, const string filename)
{
    int i=0,j=0;
    string data_cpy[MAX_NUM_STU];
    ifstream ifs(filename);
    while(!ifs.eof())
    {
        getline(ifs,data_cpy[i]);   //copy the existing data to an array
        i++;
    }
    ifs.close();
    for(j=0;j<i;j++)
    {
        //cout<<data_cpy[j]<<endl;
        //cout<<data_cpy[j].find(name)<<endl;
        if(data_cpy[j].find(name)<24 && data_cpy[j].find(name)>0)//find the target via find function
        {
            cout<<data_cpy[j]<<endl;
            return true;
        }        
    }
    
    return false;
}
 
//TODO3: calculate the average grade of all students in the file. 
//Please print out the total number of students and the average grade after calculation.
void cal_mean(const string filename)
{
    string data_str,s1;
    double grades[MAX_NUM_STU];
    ifstream ifs(filename);
    int i=0,j;                             //what():  basic_string::substr: __pos (which is 16) > this->size() (which is 13)
    double avg=0;
    while(!ifs.eof())
    {
        //cout<<i<<endl;                  //to be delete
        getline(ifs,data_str);
        if(i>=1)
        {    
            //cout<<data_str<<"  "<<data_str.length()<<endl;           //to be delete
            if (data_str.length()==0)            //copy the existing data to an array
            break;
            s1=data_str.substr(data_str.length()-4,4);
            
            grades[i]=atof(s1.c_str());   //convert into type double
            
        }    
        i++;
    }
    ifs.close();
    for(j=1;j<i;j++)
    {
        //cout<<grades[j]<<endl;
        avg=avg+grades[j];
    }
    avg=avg/(i-1);
    cout<<"Find "<<i-1<<" students in total. Mean of their grades is "<<avg<<"."<<endl;
}

int main(){
    const int id[NUM_INIT] = {1,2,3,4,5};
    const string name[NUM_INIT] = {"Bill", "Jack", "Ron", "Mark", "Donald"};
    const float grade[NUM_INIT] = {90.5, 95.5, 85.5, 93.5, 87.5};
    const string filename = "data.txt";
    init(id, name, grade, filename);

    int cmd, test_id;
    float test_grade;
    string test_name;
    bool find;

    while (true){
        cout << "Please enter: \n 1 to display all the entries\n 2 to append a new entry\n 3 to lookup an entry\n 4 to calculate the average grade\n 0 to exit: ";
        cin >> cmd;

        switch (cmd){
            case 0:
                return 0;

            case 1:
                display(filename);
                break;
            
            case 2:
                cout << "Please enter the id you want to append: ";
                cin >> test_id;
                cout << "Please enter the name you want to append: ";
                cin >> test_name;
                cout << "Please enter the grade you want to append: ";
                cin >> test_grade;
                append(test_id, test_name, test_grade, filename);
                break;
            
            case 3:
                cout << "Please enter the name you want to look up: ";
                cin >> test_name;
                find = lookup(test_name, filename);
                if (find) cout << "Find " << test_name << " successfully!" << endl;
                else cout << "Cannot find " << test_name << endl;
                break;

            case 4:
                cal_mean(filename);
                break;
            
            default:
                cout << "Wrong command!" << endl;
                break;
        }
    }
    return 0;
}