#include<iostream>
#include<string.h>
using namespace std;

enum majors {COMP, CPEG, DSCT};

struct node{
    string name;
    majors major;
    node* next;     // next node
    node* next_sm;  // next node with the same major
};


struct headnode{
    node* head;
    node* tail;
    node* comp_pointer;
    node* cpeg_pointer;
    node* dsct_pointer;
};


string Print_Key(majors in_major) {
    switch (in_major) {
        case 0: return ("COMP");
        case 1: return ("CPEG");
        case 2: return ("DSCT");
        default: return ("ERROR!");
    }
};


majors Print_Major(string in_major){
    if(in_major=="COMP")
        return majors(COMP);
    else if(in_major=="CPEG")
        return majors(CPEG);
    else if(in_major=="DSCT")
        return majors(DSCT);
    else {cout<<"ERROR!"<<endl; return majors(COMP);}
}


headnode* h = nullptr;


int Init() {
    h = new headnode;
    h->head = nullptr;
    h->tail = nullptr;
    h->comp_pointer = nullptr; // points to the first node with major = COMP
    h->cpeg_pointer = nullptr; // points to the first node with major = CPEG
    h->dsct_pointer = nullptr; // points to the first node with major = DSCT
    return 0;
}

// TODO Add() a new student with major
int Add() {
    string in_name;
    int major_num;

    cout << "Please input name:";
    cin >> in_name;
    cout << "Please input major:1 COMP 2 CPEG 3 DSCT" << endl;
    cin >> major_num;
    major_num--;
    node* node_add=new node;
    node_add->name=in_name;
    node_add->major=static_cast<majors>(major_num);
    node_add->next=nullptr;
    node_add->next_sm=nullptr;
    h->tail=node_add;
    //cout<<h->tail<<" and "<<node_add<<endl;
    node* p=nullptr; //an assistant
    if(h->head==nullptr)
    {    
        h->head=node_add; //check if this is the very first 
        //node_add->next=nullptr;
    }
    //assign the major that appears for the first time to h
    else
    {
        p=h->head;
        //cout<<"head:"<<h->head<<"  name:"<<h->head->name<<"  major:"<<Print_Key(h->head->major)<<"  next:"<<h->head->next<<endl;
        while(p->next!=nullptr) 
        {
            p=p->next;
        }
        p->next=node_add;
    }
        if(node_add->major==0 && h->comp_pointer==nullptr) 
            h->comp_pointer=node_add;
        else if(node_add->major==1 && h->cpeg_pointer==nullptr)
            h->cpeg_pointer=node_add;
        else if(node_add->major==2 && h->dsct_pointer==nullptr)
            h->dsct_pointer=node_add;
        else
        {
        
            if(node_add->major==0) //not the first
            {   
                for( p=h->comp_pointer; p->next_sm!=nullptr;p=p->next_sm);
                p->next_sm=node_add;

            }
            else if(node_add->major==1)
            {   
                for( p=h->cpeg_pointer; p->next_sm!=nullptr;p=p->next_sm);
                p->next_sm=node_add;
            }
            else if(node_add->major==2)
            {   
                for( p=h->dsct_pointer; p->next_sm!=nullptr;p=p->next_sm);
                p->next_sm=node_add;
            }
        }
    
    
    // new nodes are always added at the end

  
    cout << h->tail->name;
    cout << " Added!" << endl;
    return 0;
}



int Search() {
    node* head = h->head;
    node* tail = h->tail;
    string name;
    cout << "Please input the name:";
    cin >> name;
    node* now_node = head;
    cout<<"returned results:\n";
    if(now_node->name==name)
    {
            
        cout<<"Name:"<<now_node->name<<" "<<"Major:"<<Print_Key(now_node->major)<<endl;
        return 0;
    }
    do
    {
        now_node=now_node->next;
        if(now_node->name==name)
        {
            //cout<<"returned results:\n";
            cout<<"Name:"<<now_node->name<<" "<<"Major:"<<Print_Key(now_node->major)<<endl;
            return 0;
        }
        

    } while (now_node!=tail);
    return -1;
    // TODO Search by input the name 

}

void Print() {
    node* head = h->head;
    node* tail = h->tail;
    node* now_node = head;
    cout << "Students Information:" << endl;
    cout<<"Name:"<<now_node->name<<" "<<"Major:"<<Print_Key(now_node->major)<<endl;
    do
    {
        now_node=now_node->next;
        cout<<"Name:"<<now_node->name<<" "<<"Major:"<<Print_Key(now_node->major)<<endl;
        
    } while (now_node!=tail);

// TODO Print all students information
}

int Print_By_Major(){ 
    string in_major;
    cout<< "Please input major:"<<endl;
    cin>>in_major;
    majors m= Print_Major(in_major);
    node* ptr=nullptr;
    cout << "Students Information:" << endl;
    // TODO Print students with same major
    if(m==COMP)
    {   
        ptr=h->comp_pointer;
        do
        {
            cout<<"Name:"<<ptr->name<<" "<<"Major:"<<Print_Key(ptr->major)<<endl;
            ptr=ptr->next_sm;
        }while(ptr!=nullptr);
    }
    else if(m==CPEG)
    {
        ptr=h->cpeg_pointer;
        do
        {
            
            cout<<"Name:"<<ptr->name<<" "<<"Major:"<<Print_Key(ptr->major)<<endl;
            ptr=ptr->next_sm;
        }while(ptr!=nullptr);
    }
    else
    {
        ptr=h->dsct_pointer;
        do
        {
            cout<<"Name:"<<ptr->name<<" "<<"Major:"<<Print_Key(ptr->major)<<endl;
            ptr=ptr->next_sm;
        }while(ptr!=nullptr);
    }

    
    
    // TODO Print students with same major


    return 0;
}

void Delete_ALL(node*& head){
    
    cout<<"DELETE SUCCESS"<<endl;
    node* ptr;
    node* ptr_a;
    for (ptr=head->next,ptr_a=head;ptr!=nullptr;ptr_a=ptr,ptr=ptr->next)
    {
        cout<<"deleting "<<ptr_a->name<<endl;
        delete ptr_a;
        ptr_a=nullptr;
    }
    cout<<"deleting "<<ptr_a->name<<endl;
    delete ptr_a;
    ptr_a=nullptr;
    // TODO Delete ALL studnets 
}