#include <iostream>
#include <cstring>
#include "patient.h"
using namespace std;

/* 
    For the following tasks, feel free to define your helper function if needed.

    You are NOT allowed to modify any of the given function prototypes 
    including the return types, function names, default values, and parameter lists.

    You are NOT allowed to use array.

    You need to make sure that there is NO memory leak.
 */

//helper 3
int count_infectees(const Patient* patient)
{
   if(patient==nullptr) return 0;
   return count_infectees(patient->infectees)+count_infectees(patient->next)+1;
}
//helper 4


// Task 1: Print detailed information of a given patient, including the total count of following cases which are epidemiologically linked to him/her
void printPatientDetails(const Patient* patient){
    if(patient==nullptr) return;
    
    cout<<"ID:"<<patient->ID<<endl;
    cout<<"Date of Infection:"<<patient->date_of_infection<<endl;
    cout<<STATUS_NAME[patient->current_status]<<endl;
    cout<<"Date of Recovery or Death:"<<patient->date_of_recovery_or_death<<endl;
    cout<<"Location:"<<DISTRICT_NAMES[patient->location]<<endl;
    cout<<"Total infectees:"<<count_infectees(patient->infectees);//to be continued
};

// Task 2: Print tree view of Patient Database. 
void printPatientDatabase(const Patient* root, int vertical_alignment){
    
    if(root==nullptr)
        return;
    for(int i=0;i<vertical_alignment;i++)
        cout<<'\t';
    cout<<"ID:"<<root->ID<<endl;
    if(root->infectees!=nullptr)
        printPatientDatabase(root->infectees,vertical_alignment+1);
    if(root->next!=nullptr)
        printPatientDatabase(root->next,vertical_alignment);
};

// Taks 3: Print the number of newly confirmed cases for a given day
int printDailyStat(const Patient* root, int day){
    if(root==nullptr)
    {
        return 0;
    }    
    
    if(root->date_of_infection==day)
    {    
        return printDailyStat(root->next, day)+printDailyStat(root->infectees, day)+1;
    }
    else
    {
        return printDailyStat(root->next, day)+printDailyStat(root->infectees, day);
    }
}
// Task 4: search Patient by the given ID. Returns 3 pointers by reference.
void searchPatientByID(int ID, Patient*& current, Patient*& previous, Patient*& parent)
{
    if(current==nullptr) //when already reach the leaf
        return;
    if(current->ID==ID) //the root itself is target
        return;    
    Patient* my_par=parent;
    Patient* my_pre=previous;
    if(current->infectees!=nullptr)
    {
        previous=nullptr;
        parent=current;
        current=current->infectees;
        searchPatientByID(ID,current,previous,parent);
        if(current==nullptr)
        {
            parent=nullptr;
            previous=nullptr;
            return;
        }    
        if(current->ID==ID)
        {
            return;
        }    
    }
    if(current->next!=nullptr)
    {   
        previous=current;
        current=current->next;
        parent=my_par;
        searchPatientByID(ID,current,previous,parent);
        if(current==nullptr)
        {
            parent=nullptr;
            previous=nullptr;
            return;
        }    
        if(current->ID==ID)
            return;
    }    
    previous=my_pre;
    current=my_par;
};
// Task 5: Remove all cases who have recovered or deceased
void delete_node(Patient* &root, Patient* &current){

    if(current==nullptr) return;
    Patient* parent=nullptr;
    Patient* previous = nullptr;
    Patient* dup_root=root;
    Patient* p=nullptr;//working ptr
    Patient* dul_current=current;
    bool true_head=false;
    bool true_has_infector=false;
    bool true_infectees=false;
    
    if(current->next!=nullptr) delete_node(dup_root,current->next);
    if(current->infectees!=nullptr) delete_node(dup_root,current->infectees);
    
    if(current->current_status==1 || current->current_status==2)
    {
        
        parent=nullptr;
        previous = nullptr;
        
        searchPatientByID(current->ID,dup_root,previous,parent);
        if(previous==nullptr) true_head=true;
        if(parent!=nullptr) true_has_infector=true;
        if(current->infectees!=nullptr) true_infectees=true;

        if(!true_head && !true_has_infector && !true_infectees) //rule 0
        {   
            previous->next=current->next;
            delete dul_current;
            dul_current=nullptr;
        }
        else if(!true_head && !true_has_infector && true_infectees) //rule 1
        {   
            p=dul_current->infectees;
            while(p->next!=nullptr)
            {
                p=p->next;
            }
            if(dul_current->next!=nullptr)
                p->next=dul_current->next;
            //dul_current->infectees=dul_current->next;
            previous->next=dul_current->infectees;

            delete dul_current;
            dul_current=nullptr;
        }
        else if(!true_head && true_has_infector && !true_infectees) //rule 2
        {  
            previous->next=dul_current->next;
            delete dul_current;
            dul_current=nullptr;
        }
        else if(!true_head && true_has_infector && true_infectees) //rule 3
        {  
            p=dul_current->infectees;
            while(p->next!=nullptr)
            {
                p=p->next;
            }
            if(dul_current->next!=nullptr)
                p->next=dul_current->next;
            //for(p=dul_current->infectees;p->next!=nullptr;p=p->next);
            p->next=dul_current->next;
            previous->next= dul_current->infectees;
            delete dul_current;
            dul_current=nullptr;
        }
        else if(true_head && !true_has_infector && !true_infectees) //rule 4
        {  
            Patient* another_root=root;
            root=another_root->next;
            delete dul_current;
            dul_current=nullptr;
            
        }
        else if(true_head && !true_has_infector && true_infectees) //rule 5
        { 
            Patient* another_root=root;
            //for(p=dul_current->infectees;p->next!=nullptr;p=p->next);
            p=dul_current->infectees;
            while(p->next!=nullptr)
            {
                p=p->next;
            }
            if(dul_current->next!=nullptr)
                p->next=dul_current->next;
            root=another_root->infectees;
            delete dul_current;
            dul_current=nullptr;
        }
        else if(true_head && true_has_infector && !true_infectees) //rule 6
        {  
            parent->infectees=dul_current->next;
            delete dul_current;
            dul_current=nullptr;
        }
        else  //rule 7
        {  
            //for(p=dul_current->infectees;p->next!=nullptr;p=p->next);
            
            p=dul_current->infectees;
            while(p->next!=nullptr)
            {
                p=p->next;
            }
            if(dul_current->next!=nullptr)
                p->next=dul_current->next;
            parent->infectees=dul_current->infectees;
            delete dul_current;
            dul_current=nullptr;
        }
    }
};
// Task 6: Remove all cases
void removeInactive(Patient* &root)
{
    delete_node(root,root);
};

void deleteAllPatients(Patient* &root){
    if(root==nullptr) return;
    if(root->infectees!=nullptr)
    deleteAllPatients(root->infectees);
    if(root->next!=nullptr)
    deleteAllPatients(root->next);
    delete root;
    root=nullptr;
};