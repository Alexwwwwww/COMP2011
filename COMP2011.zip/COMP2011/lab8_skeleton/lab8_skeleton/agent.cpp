#include <iostream>
#include <cstdlib>
#include "agent.h"
using namespace std;


State* observe(const char map[10][10], const int map_size, const int goal_loc[2], int agent_loc[2])
{
	State* curr_state = new State;

	// TODO1
	/* 
		You are required to:
			1.	Detect obstacles within a radius of SENSOR_RANGE;
			2.	Fill in all the fields of `curr_state`;
			3.	Delete those dynamically allocated variables, if any.
	*/
	curr_state->obstacle[0]=0;
	curr_state->obstacle[1]=0;
	curr_state->goal_loc[0]=goal_loc[0];
	curr_state->goal_loc[1]=goal_loc[1];
	curr_state->curr_loc[0]=agent_loc[0];
	curr_state->curr_loc[1]=agent_loc[1];
	curr_state->map_size=map_size;
	int i,j;
	for (i=agent_loc[0];i<=agent_loc[0]+2;i++)
	{
		for (j=agent_loc[1];j<=agent_loc[1]+2;j++)
		{
			if(i<0 || i>=map_size || j<0 || j>=map_size)
				continue; // see if out of range
			if((i-agent_loc[0])*(i-agent_loc[0])+(j-agent_loc[1])*(j-agent_loc[1])>4)
				continue; //see if larger than radius
			if(map[agent_loc[0]][agent_loc[1]]=='x') //if there is obstacle
			{
				curr_state->obstacle[0]=i;
				curr_state->obstacle[1]=j;
			}
		}
	}	
	// TODO1 ends
	return curr_state;
}


Action* think(const State* curr_state)
{
	int	min_dist_to_goal = 999;
	Action* best_action = new Action;

	Action actions[4] = {N, S, E, W};
	for (int i = 0; i < 4; ++i)
	{
		int next_x, next_y;          // basic algorithm: first keep going forward to rech the same 
									 // x index of the goal
		switch (actions[i])          // (if there is obstacle, go down for 1 unit and keep forwad)
		{                            // after it reaches the same x index, go downward
			case N:                  // in these maps there won't be any problem at least
				next_x = curr_state->curr_loc[0] - 1;  
				next_y = curr_state->curr_loc[1];
				break;
			case S:
				next_x = curr_state->curr_loc[0] + 1;
				next_y = curr_state->curr_loc[1];
				break;
			case E:
				next_x = curr_state->curr_loc[0];
				next_y = curr_state->curr_loc[1] + 1;
				break;
			case W:
				next_x = curr_state->curr_loc[0];
				next_y = curr_state->curr_loc[1] - 1;
				break;
		}

		// TODO2
		/*
			1.	You need to implement your own path finding algorithm, i.e. decide next action base
			   	on the current state.
			2.	The algorithm should AT LEAST help the agent reach the goals which are specified in
				the lab web page.
			3.	Delete those dynamically allocated variables, if any.
		*/
		if(curr_state->curr_loc[1]<curr_state->goal_loc[1])      //see if it is above the goal
		{
			if(curr_state->curr_loc[0]!=curr_state->obstacle[0])  //no obstacle ahead
				best_action=&actions[2];
			else
				best_action=&actions[1];             //there is obstacle ahead, go down
		}
		else if(curr_state->curr_loc[1]==curr_state->goal_loc[1]) //right above the goal
		{
			best_action=&actions[1];
		}
		// TODO2 ends
	}
	return best_action;
}

int* act(State* curr_state, Action* action)
{
	int next_x, next_y;
	switch (*action)
	{
		case N:
			next_x = curr_state->curr_loc[0] - 1;
			next_y = curr_state->curr_loc[1];
			break;
		case S:
			next_x = curr_state->curr_loc[0] + 1;
			next_y = curr_state->curr_loc[1];
			break;
		case E:
			next_x = curr_state->curr_loc[0];
			next_y = curr_state->curr_loc[1] + 1;
			break;
		case W:
			next_x = curr_state->curr_loc[0];
			next_y = curr_state->curr_loc[1] - 1;
			break;
	}

	// TODO3
	/*
		You are required to:
			1.	Return the next location based on the given action
			2.	Refresh the agent's memory, i.e. delete variables used in previous rounds.
	*/
	delete curr_state;
	curr_state=nullptr;
	int* next_loc=new int[2];
	next_loc[0]=next_x;
	next_loc[1]=next_y;
	return next_loc;
	// TODO3 ends
}


bool reach_goal(const int curr_loc[2], const int goal_loc[2])
{
	if (curr_loc[0] == goal_loc[0] && curr_loc[1] == goal_loc[1])
	{
		return true;
	}
	return false;
}
