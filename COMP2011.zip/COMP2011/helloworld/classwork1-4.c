#include<stdio.h>
int main()
{
    int year;
    float GPA;
    printf("what is your year:");
    scanf("%d",&year);
    //printf("\n");
    printf("what is your GPA:");
    scanf("%f",&GPA);
    
    printf("I am an year %d student with GPA %f",year,GPA);
    return 0;
}