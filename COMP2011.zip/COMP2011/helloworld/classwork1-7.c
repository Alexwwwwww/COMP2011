#include <stdio.h>
#include <stdbool.h>

const float PI=3.14159;
// your function starts here
float circleArea(float r)
{
    return r*r*PI;
}
// your function ends here

int main() {
  printf("%f", circleArea(5.0f));
  return 0;
}