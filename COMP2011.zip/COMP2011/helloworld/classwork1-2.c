#include <stdio.h>

int main() {
    float a = 4.0f;
    float b = 3.7f;
    printf("before swapping, a = %f, b = %f\n", a, b);
    
    // your code starts here
    float temp;
    temp=a;
    a=b;
    b=temp;
    // your code ends here
    
    printf("after swapping, a = %f, b = %f\n", a, b);
    return 0;
}