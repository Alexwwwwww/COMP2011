#include <stdio.h>
#include <string.h> // uncomment this line if needed

int main()
{
    char input[] = "Welcome to HKUST Robotics Team Software Tutorial";
    printf("Before trimming: %s\n", input);

    // your code starts here
    int i;
    for (i = 0; input[i] != '\0'; i++)
    {
        if (input[i] != ' ')
            printf("%c", i);
        else
        {
            input[i]='\0';
            break;
        }    
    }
    // your code ends here

    printf("After trimming: %s\n", input);
    return 0;
}